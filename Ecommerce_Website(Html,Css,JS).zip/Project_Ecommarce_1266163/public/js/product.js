const productImages = document.querySelectorAll(".product-images img");
const productImageSlide = document.querySelector(".image-slider");

let activeImageSlide=0;
productImages.forEach((item, i)=>{
    item.addEventListener('click', ()=>{
      productImages[activeImageSlide].classList.remove('active');
      item.classList.add('active');
      productImageSlide.style.backgroundImage= `url('${item.src}')`;
      activeImageSlide= i;
    })
})

//toggle size buttons

const sizeBtns = document.querySelectorAll('.size-radio-btn');
let checkedBtn=0;
sizeBtns.forEach((item, i)=>{
    item.addEventListener('click', ()=>{
      sizeBtns[checkedBtn].classList.remove('check');
      item.classList.add('check');
      checkedBtn=i;
    }) 
})



let imageSrc = localStorage.getItem("imageSrc");
let brand = localStorage.getItem("brand");
let actualPrice = localStorage.getItem("actualPrice");
let price = localStorage.getItem("price");
let shortDescript = localStorage.getItem("shortDescript");


let changableProductImage = document.querySelector(".image-slider");
let changableProductBrand = document.querySelector(".product-brand");
let changableProductShortDescription = document.querySelector(".product-short-des");
let changableProductPrice = document.querySelector(".product-price");
let changableProductActualPrice = document.querySelector(".product-actual-price");
let productImage = document.querySelector(".product-images");

if (imageSrc && brand && actualPrice && price && shortDescript) {
  changableProductImage.style.backgroundImage = `URL(${imageSrc})`;
  changableProductImage.style.backgroundSize = `contain`;
  changableProductImage.style.backgroundPosition = `center`;
  changableProductImage.style.backgroundRepeat = `no-repeat`;
  changableProductBrand.innerHTML = brand;
  changableProductShortDescription.innerHTML = shortDescript;
  changableProductPrice.innerHTML = price;
  changableProductActualPrice.innerHTML = actualPrice;
  productImage.style.display = "none";
}
