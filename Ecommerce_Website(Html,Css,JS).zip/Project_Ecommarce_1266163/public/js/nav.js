const createNav=()=>{
    let nav= document.querySelector('.navbar');

    nav.innerHTML=`
      <div class="nav">
          <img src="img/dark-logo.png" class="brand-logo" alt="">
          <div class="nav-items">
              <div class="search">
                <input type="text" class="search-box" placeholder="search brand, product">
                <a href="product.html"class="search-btn">search</a>
              </div>
              <a href="#"><img src="img/user.png" alt=""></a>
              <a href="#"><img src="img/cart.png" alt=""></a>
            </div>
      </div>

      <ul class="links-container">
      <li class="link-item"><a href="index.html" class="link">home</a></li>
      <li class="link-item"><a href="product.html" class="link">women</a></li>
      <li class="link-item"><a href="#men"onclick="showByCategory('.men')" class="link men">men</a></li>
      <li class="link-item"><a href="product.html" class="link">kids</a></li>
      <li class="link-item"><a href="#shoes" onclick="showByCategory('.shoes')" class="link shoes">Shoes</a></li>
    </ul>
    `;
    
}

function showByCategory(className){
    let categories = document.querySelectorAll(".categories");
    let products = document.querySelectorAll(className);
    let productShow =   products[1];
    for(let category of categories){
      category.style.display = "none";
      productShow.style.display = "block";
  }
}
createNav();





