const productContainer=[...document.querySelectorAll('.product-container')];
const nxtBtn = [...document.querySelectorAll('.nxt-btn')];
const preBtn = [...document.querySelectorAll('.pre-btn')];


productContainer.forEach((item, i)=>{
  let containerDimenstions = item.getBoundingClientRect();
  let containerWidth= containerDimenstions.width;

  nxtBtn[i].addEventListener('click',()=>{
    item.scrollLeft +=containerWidth;
  })
  preBtn[i].addEventListener('click',()=>{
    item.scrollLeft -=containerWidth;
  })
})


let productCard = document.querySelectorAll(".product-card");

for (let product of productCard) {
  product.addEventListener("click", ()=>{
    // console.log(product);
    let productChilds = product.children;
    // console.log(productChilds);
    let imageChild = productChilds[0];
    // console.log(imageChild);
    let imgTag = imageChild.children[1];
    // console.log(imgTag);
    let imageSrc = imgTag.getAttribute("src");
    localStorage.setItem("imageSrc", imageSrc);


    let productInfo = productChilds[1];
    let infoChildrens = productInfo.children;
    let brand = infoChildrens[0].innerHTML;
    localStorage.setItem("brand", brand);
    let shortDescript = infoChildrens[1].innerHTML;
    localStorage.setItem("shortDescript", shortDescript);
    let price = infoChildrens[2].innerHTML;
    localStorage.setItem("price", price);
    let actualPrice = infoChildrens[3].innerHTML;
    localStorage.setItem("actualPrice", actualPrice);
    
    let currentLocation = document.location.href;
    let locationArray =currentLocation.split("/");
    locationArray[locationArray.length-1] = "product.html"
    locationArray = locationArray.join("/");
    window.location = locationArray;
  });
}

